//
//  UploadTaskViewController.h
//  NSURLSessionDemo
//
//  Created by huangwenchen on 15/3/25.
//  Copyright (c) 2015年 huangwenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UploadImageViewController : UIViewController

@end
